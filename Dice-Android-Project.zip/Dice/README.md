# 骰子 Android App

- 应用名称：骰子
- 包名：com.example.dice
- Kotlin + XML
- minSdk 24 / targetSdk 34 / compileSdk 34
- 无网络、广告、登录、后台服务和自定义权限
- 使用 Unicode 骰子符号 ⚀ ⚁ ⚂ ⚃ ⚄ ⚅
