package com.example.dice

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlin.random.Random

class MainActivity : Activity() {

    private lateinit var diceTextView: TextView
    private lateinit var rollButton: Button

    private val diceFaces = arrayOf("⚀", "⚁", "⚂", "⚃", "⚄", "⚅")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        diceTextView = findViewById(R.id.diceTextView)
        rollButton = findViewById(R.id.rollButton)

        rollButton.setOnClickListener {
            rollDice()
        }

        updateDice(1)
    }

    private fun rollDice() {
        val result = Random.nextInt(from = 1, until = 7)
        updateDice(result)
    }

    private fun updateDice(value: Int) {
        diceTextView.text = diceFaces[value - 1]
        diceTextView.contentDescription = getString(R.string.dice_result_description, value)
    }
}
